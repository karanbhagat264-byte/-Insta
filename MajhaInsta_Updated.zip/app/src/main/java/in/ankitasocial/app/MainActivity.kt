package in.ankitasocial.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import coil.compose.AsyncImage
import android.net.Uri

private val Ink = Color(0xFF151521)
private val Purple = Color(0xFF7857FF)
private val Pink = Color(0xFFFF5D9E)
private val Muted = Color(0xFF77778A)

data class SocialPost(
    val id: Long,
    val author: String,
    val caption: String,
    val image: String? = null,
    val likes: Int = 0,
    val liked: Boolean = false,
    val saved: Boolean = false,
    val comments: List<String> = emptyList(),
    val sample: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnkitaSocialApp() }
    }
}

@Composable
fun AnkitaSocialApp() {
    var tab by remember { mutableIntStateOf(0) }
    var dark by remember { mutableStateOf(false) }
    var privateProfile by remember { mutableStateOf(true) }
    var username by remember { mutableStateOf("माझे खाते") }
    var query by remember { mutableStateOf("") }
    var caption by remember { mutableStateOf("") }
    var selectedImage by remember { mutableStateOf<Uri?>(null) }
    var commentTarget by remember { mutableStateOf<Long?>(null) }
    var commentText by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf<String?>(null) }
    var nextId by remember { mutableLongStateOf(10L) }
    var posts by remember {
        mutableStateOf(listOf(
            SocialPost(1, "sahyadri.frames", "निसर्गातला एक शांत क्षण.", likes = 128, sample = true),
            SocialPost(2, "daily.canvas", "आजचा रंग, आजची ऊर्जा.", likes = 86, sample = true),
            SocialPost(3, "travel.with.me", "नव्या वाटा शोधत राहा.", likes = 241, sample = true)
        ))
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedImage = uri
    }
    val bg = if (dark) Color(0xFF11111A) else Color(0xFFFCFBFF)
    val card = if (dark) Color(0xFF1D1D2A) else Color.White
    val fg = if (dark) Color.White else Ink

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Purple, background = bg, surface = card)
        else lightColorScheme(primary = Purple, background = bg, surface = card)) {
        Scaffold(
            containerColor = bg,
            topBar = {
                Row(Modifier.fillMaxWidth().background(card).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("ankita", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = fg)
                        Text("तुमचा सामाजिक अवकाश", fontSize = 11.sp, color = Muted)
                    }
                    IconButton(onClick = { tab = 4 }) { Icon(Icons.Default.Tune, "सेटिंग्ज", tint = fg) }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = card) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("फीड") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("शोध") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.AddCircle, null) }, label = { Text("पोस्ट") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("प्रोफाइल") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> FeedScreen(Modifier.padding(padding), posts, card, fg,
                    onLike = { id -> posts = posts.map { if (it.id == id) it.copy(liked = !it.liked, likes = (it.likes + if (it.liked) -1 else 1).coerceAtLeast(0)) else it } },
                    onSave = { id -> posts = posts.map { if (it.id == id) it.copy(saved = !it.saved) else it } },
                    onComment = { commentTarget = it },
                    onMore = { notice = "ही ऑफलाइन नमुना आवृत्ती आहे. इतर वापरकर्त्यांना पोस्ट दिसत नाहीत." })
                1 -> {
                    Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                        Text("पोस्ट शोधा", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = fg)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(),
                            label = { Text("वापरकर्ते किंवा मजकूर") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                        Spacer(Modifier.height(12.dp))
                        val matches = posts.filter { it.author.contains(query, true) || it.caption.contains(query, true) }
                        if (matches.isEmpty()) Text("काही सापडले नाही.", color = Muted)
                        else matches.forEach { Text("@${it.author}  ·  ${it.caption}", color = fg, modifier = Modifier.fillMaxWidth().clickable { tab = 0 }.padding(vertical = 12.dp)) }
                    }
                }
                2 -> {
                    Column(Modifier.padding(padding).fillMaxSize().padding(18.dp)) {
                        Text("नवीन पोस्ट", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = fg)
                        Text("फोटो निवडा आणि कॅप्शन लिहा.", color = Muted)
                        Spacer(Modifier.height(18.dp))
                        OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp)); Text("गॅलरीमधून फोटो निवडा")
                        }
                        selectedImage?.let { uri ->
                            Spacer(Modifier.height(12.dp))
                            AsyncImage(model = uri, contentDescription = "निवडलेला फोटो", modifier = Modifier.fillMaxWidth().height(230.dp), contentScale = ContentScale.Crop)
                        }
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(caption, { caption = it }, modifier = Modifier.fillMaxWidth(),
                            label = { Text("कॅप्शन") }, minLines = 3, maxLines = 5)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = {
                            if (selectedImage == null && caption.isBlank()) notice = "पोस्ट करण्यासाठी फोटो किंवा कॅप्शन आवश्यक आहे."
                            else {
                                posts = listOf(SocialPost(nextId++, "माझे खाते", caption.ifBlank { "माझी नवीन पोस्ट" }, selectedImage?.toString())) + posts
                                caption = ""; selectedImage = null; tab = 0
                                notice = "पोस्ट या फोनवरील सध्याच्या सत्रात जोडली."
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Publish, null); Spacer(Modifier.width(8.dp)); Text("पोस्ट तयार करा") }
                        Spacer(Modifier.height(12.dp))
                        Text("टीप: पोस्ट सध्या स्थानिक नमुना आहे; ती इंटरनेटवर अपलोड होत नाही.", color = Muted, fontSize = 12.sp)
                    }
                }
                3 -> {
                    Column(Modifier.padding(padding).fillMaxSize().padding(20.dp)) {
                        Box(Modifier.size(82.dp).background(Brush.linearGradient(listOf(Purple, Pink)), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(42.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(username, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = fg)
                        Text("@ankita_demo", color = Muted)
                        Spacer(Modifier.height(18.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            Stat(posts.count { !it.sample }.toString(), "तुमच्या पोस्ट")
                            Stat(posts.sumOf { if (it.liked) 1 else 0 }.toString(), "आवडलेल्या")
                            Stat(posts.count { it.saved }.toString(), "जतन केलेल्या")
                        }
                        Spacer(Modifier.height(20.dp))
                        OutlinedTextField(username, { username = it }, modifier = Modifier.fillMaxWidth(), label = { Text("प्रोफाइल नाव") }, singleLine = true)
                        Spacer(Modifier.height(12.dp))
                        Text("तुमच्या पोस्ट", fontWeight = FontWeight.Bold, color = fg)
                        posts.filter { !it.sample }.forEach { Text("• ${it.caption}", color = fg, modifier = Modifier.padding(vertical = 7.dp)) }
                        if (posts.none { !it.sample }) Text("अजून पोस्ट नाहीत.", color = Muted)
                    }
                }
                else -> SettingsScreen(Modifier.padding(padding), card, fg, dark, { dark = it }, privateProfile, { privateProfile = it }, { notice = it })
            }
            if (commentTarget != null) {
                val post = posts.firstOrNull { it.id == commentTarget }
                AlertDialog(onDismissRequest = { commentTarget = null },
                    title = { Text("टिप्पण्या") },
                    text = {
                        Column {
                            post?.comments?.forEach { Text(it, modifier = Modifier.padding(vertical = 3.dp)) }
                            OutlinedTextField(commentText, { commentText = it }, label = { Text("टिप्पणी लिहा") }, singleLine = true)
                        }
                    },
                    confirmButton = { TextButton(onClick = {
                        if (commentText.isNotBlank()) posts = posts.map { if (it.id == commentTarget) it.copy(comments = it.comments + commentText.trim()) else it }
                        commentText = ""; commentTarget = null
                    }) { Text("जोडा") } },
                    dismissButton = { TextButton(onClick = { commentTarget = null }) { Text("बंद") } })
            }
            notice?.let { message ->
                AlertDialog(onDismissRequest = { notice = null }, title = { Text("अंकिता सोशल") }, text = { Text(message) },
                    confirmButton = { TextButton(onClick = { notice = null }) { Text("ठीक आहे") } })
            }
        }
    }
}

@Composable
fun FeedScreen(modifier: Modifier, posts: List<SocialPost>, card: Color, fg: Color,
               onLike: (Long) -> Unit, onSave: (Long) -> Unit, onComment: (Long) -> Unit, onMore: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        item {
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                StoryBubble("तुमची", Purple, true); StoryBubble("मित्र", Pink); StoryBubble("प्रवास", Color(0xFF28A89B))
                StoryBubble("फोटो", Color(0xFFFFA23A)); StoryBubble("संगीत", Color(0xFF5B87F5))
            }
            Spacer(Modifier.height(18.dp))
            Text("तुमच्यासाठी", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = fg)
            Text("नमुना पोस्ट आणि तुमच्या स्थानिक पोस्ट", fontSize = 12.sp, color = Muted)
            Spacer(Modifier.height(12.dp))
        }
        items(posts, key = { it.id }) { post ->
            Card(Modifier.fillMaxWidth().padding(bottom = 15.dp), colors = CardDefaults.cardColors(containerColor = card),
                shape = RoundedCornerShape(22.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).background(Brush.linearGradient(listOf(Purple, Pink)), CircleShape), contentAlignment = Alignment.Center) {
                        Text(post.author.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Text(post.author, fontWeight = FontWeight.SemiBold, color = fg)
                        Text(if (post.sample) "नमुना खाते" else "तुमची स्थानिक पोस्ट", fontSize = 11.sp, color = Muted)
                    }
                    IconButton(onClick = onMore) { Icon(Icons.Default.MoreHoriz, "अधिक", tint = fg) }
                }
                if (post.image != null) {
                    AsyncImage(model = post.image, contentDescription = "पोस्ट फोटो",
                        modifier = Modifier.fillMaxWidth().height(280.dp), contentScale = ContentScale.Crop)
                } else {
                    val shade = when (post.id % 3L) { 0L -> Color(0xFFC8D0F6); 1L -> Color(0xFFB7DAD2); else -> Color(0xFFF1C5D5) }
                    Box(Modifier.fillMaxWidth().height(210.dp).background(Brush.linearGradient(listOf(shade, shade.copy(alpha = .6f), Purple.copy(alpha = .3f)))),
                        contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Photo, null, tint = Color.White, modifier = Modifier.size(48.dp))
                            Text("ANKITA SOCIAL", color = Color.White, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                            if (post.sample) Text("डेमो पोस्ट", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onLike(post.id) }) { Icon(if (post.liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "आवडले", tint = if (post.liked) Pink else fg) }
                    IconButton(onClick = { onComment(post.id) }) { Icon(Icons.Default.ModeComment, "टिप्पणी", tint = fg) }
                    IconButton(onClick = onMore) { Icon(Icons.Default.Share, "शेअर", tint = fg) }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { onSave(post.id) }) { Icon(if (post.saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "जतन", tint = fg) }
                }
                Text("${post.likes} आवडी", modifier = Modifier.padding(start = 15.dp), fontWeight = FontWeight.SemiBold, color = fg, fontSize = 13.sp)
                Text(post.caption, modifier = Modifier.padding(start = 15.dp, end = 15.dp, top = 5.dp, bottom = 15.dp), color = fg)
            }
        }
        item { Text("ऑफलाइन प्रोटोटाइप — पोस्ट इतर वापरकर्त्यांना दिसत नाहीत.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 20.dp)) }
    }
}

@Composable
fun StoryBubble(label: String, color: Color, plus: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(58.dp)) {
        Box(Modifier.size(56.dp).background(Brush.linearGradient(listOf(color, Pink)), CircleShape).padding(3.dp).background(Color.White, CircleShape).padding(3.dp).background(color.copy(alpha = .24f), CircleShape), contentAlignment = Alignment.Center) {
            if (plus) Icon(Icons.Default.Add, null, tint = Purple) else Text(label.take(1), color = color, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Spacer(Modifier.height(5.dp)); Text(label, fontSize = 11.sp, color = Muted, maxLines = 1)
    }
}

@Composable
fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun SettingsScreen(modifier: Modifier, card: Color, fg: Color, dark: Boolean, onDark: (Boolean) -> Unit,
                   privateProfile: Boolean, onPrivate: (Boolean) -> Unit, onNotice: (String) -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("तुमची सेटिंग्ज", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = fg)
        Text("गोपनीयता आणि अ‍ॅप पर्याय", color = Muted)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                SettingToggle("खाजगी प्रोफाइल", "फक्त या नमुन्यातील स्थानिक सेटिंग", privateProfile, onPrivate)
                HorizontalDivider()
                SettingToggle("डार्क मोड", "कमी प्रकाशात वापरण्यासाठी", dark, onDark)
            }
        }
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("सुरक्षा आणि गोपनीयता", fontWeight = FontWeight.Bold, color = fg)
                Spacer(Modifier.height(8.dp))
                SecurityRow("पासवर्ड संकलन", "नाही")
                SecurityRow("अनावश्यक परवानग्या", "नाही")
                SecurityRow("सर्व्हर / नेटवर्क", "नाही")
                SecurityRow("खाते आणि सिंक", "नाही")
                Text("ही ऑफलाइन आवृत्ती आहे. खाजगी प्रोफाइलचा पर्याय इतर वापरकर्त्यांवरील प्रवेश नियंत्रित करत नाही.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { onNotice("अ‍ॅपमधील सध्याची पोस्ट/आवडी/टिप्पण्या फक्त सध्याच्या सत्रात आहेत. बॅकएंड किंवा क्लाउड सेवेशी जोडलेले नाही.") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Info, null); Spacer(Modifier.width(8.dp)); Text("या आवृत्तीबद्दल")
        }
    }
}

@Composable
fun SettingToggle(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, fontSize = 11.sp, color = Muted) }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
fun SecurityRow(title: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontSize = 13.sp); Text(value, fontSize = 13.sp, color = Purple, fontWeight = FontWeight.SemiBold)
    }
}
